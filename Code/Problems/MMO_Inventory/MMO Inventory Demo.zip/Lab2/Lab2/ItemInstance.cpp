#include "ItemInstance.h"

// Constructor
ItemInstance::ItemInstance(ItemDef * aItemDefinition)
{
	itemDefinition = aItemDefinition;
	currentStack = 1;
}

ItemInstance::~ItemInstance()
{
	
}

// adds one to stack and returns a boolean if another can be added to the stack or not based on the ItemDef's max stack size
bool ItemInstance::AddOneToStack()
{
	if (currentStack < itemDefinition->GetMaxStackSize())
	{
		currentStack++;
		return true;
	}
	else
	{
		return false;
	}	
}

// removes an item from the stack
bool ItemInstance::RemoveOneFromStack()
{
	currentStack--;
	if (currentStack != 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

// returns item Definition (used a lot)
ItemDef* ItemInstance::GetItemDefinition()
{
	return itemDefinition;
}
