#include "ItemDef.h"
#include <iostream>
#include <string>

unsigned int ItemDef::lastUniqueId = 0;

// Default constructor
ItemDef::ItemDef()
{
	uniqueId = GetNextUniqueItemId();
	name = "";
	itemType = ItemType::CONSUMABLE;
	maxStackSize = 99;
}

// Overloaded constructor
ItemDef::ItemDef(std::string aName, ItemType aType, unsigned int aSize)
{
	uniqueId = GetNextUniqueItemId();
	name = aName; 
	itemType = aType;
	maxStackSize = aSize;
}

ItemDef::~ItemDef()
{

}

// sets name of item associated with ItemDef
void ItemDef::SetName(std::string aName)
{
	name = aName;
}

// returns name of ItemDef
std::string ItemDef::GetName()
{
	return name;
}

// sets the Enum Type of ItemDef
void ItemDef::SetItemType(ItemType aItemType)
{
	itemType = aItemType;
}

// returns itemType
ItemType ItemDef::GetItemType()
{
	return itemType;
}

// sets stack size
void ItemDef::SetMaxStackSize(int aMaxStackSize)
{
	maxStackSize = aMaxStackSize;
}

// returns stack size
unsigned int ItemDef::GetMaxStackSize()
{
	return maxStackSize;
}
// prints hello world
void ItemDef::Print()
{
	std::cout << "Hello World!";
}

// returns an item type name associated with the corresponding Enum indexes.
std::string ItemDef::GetItemTypeName()
{
	std::string ItemTypeName;

	switch (itemType)
	{
	case ItemType::WEAPON:
	{
		ItemTypeName = "Weapon";
	}
	break;
	case ItemType::ARMOR:
	{
		ItemTypeName = "Armor";
	}
	break;
	case ItemType::CONSUMABLE:
	{
		ItemTypeName = "Consumable";
	}
	break;
	case ItemType::CRAFTING_MATERIAL:
	{
		ItemTypeName = "Crafting Material";
	}
	break;
	case ItemType::WEARABLE:
	{
		ItemTypeName = "Wearable";
	}
	break;
	case ItemType::BIND_ON_PICKUP:
	{
		ItemTypeName = "Bind_On_Pickup";
	}
	
	default:
	{

	}
	break;
	}

	return ItemTypeName;
}
