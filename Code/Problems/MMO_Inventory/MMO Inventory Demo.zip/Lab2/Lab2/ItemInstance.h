#pragma once
#include "ItemDef.h"

// This class holds information about a particular item instance inside an inventory
class ItemInstance
{
public:
	ItemInstance(ItemDef *aItemDefinition);
	~ItemInstance();

	// Get the quantity in this stack
	unsigned int GetStackCount() { return currentStack; }
	
	// Add another item to this stack
	// Returns true if successfully, false otherwise
	bool AddOneToStack();

	bool RemoveOneFromStack();

	ItemDef* GetItemDefinition();

private:

	// My current stack size
	unsigned int currentStack;

	// A pointer to the item definition of this item
	ItemDef *itemDefinition;

};

