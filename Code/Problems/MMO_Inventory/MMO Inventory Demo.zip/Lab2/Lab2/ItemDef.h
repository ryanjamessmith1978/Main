#pragma once
#include <string>

// What types an item can be
enum ItemType {
	
	DEFAULT = 0,
	ARMOR = 1,
	CONSUMABLE = 2,
	CRAFTING_MATERIAL = 4,
	WEARABLE = 8,
	BIND_ON_PICKUP = 16,
	WEAPON = 32
	
};

// This class defines an Item Definition
class ItemDef
{
public:
	ItemDef();
	ItemDef(std::string aName, ItemType aType, unsigned int aSize);
	~ItemDef();

	// Get/Set functions for the item name
	void SetName(std::string aName);
	std::string GetName();
	
	// Add/Get functions for the item type
	void SetItemType(ItemType aItemType);
	ItemType GetItemType();
	std::string GetItemTypeName();

	// Get/Set the max stack size
	void SetMaxStackSize(int aMaxStackSize);
	unsigned int GetMaxStackSize();

	// Print the item definition
	void Print();

	// Get the unique id for this item
	 unsigned int GetUniqueId() { return uniqueId; }
	
private:
	
	// Unique id system so that all items get a unique id
	static unsigned int GetNextUniqueItemId()
	{
		return lastUniqueId++;
	}
	
	// The last unique id used
	static unsigned int lastUniqueId;

	// Unique id of this item
	unsigned int uniqueId;

	// The name of this item
	std::string name;

	// The types of item this item is (can be more than one)
	ItemType itemType;

	// Max stack size this item has
	unsigned int maxStackSize;

	
};

