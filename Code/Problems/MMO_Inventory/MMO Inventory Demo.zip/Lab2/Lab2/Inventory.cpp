// Inventory.cpp

#include "Inventory.h"
#include <iostream>
#include <string>
#include <map>


Inventory::Inventory(ItemType aItemType)
{
	inventoryType = aItemType;
}

Inventory::~Inventory()
{

}

// Adds item to inventory
void Inventory::AddItemToInventory(ItemInstance aItemInstance)
{
	int LastInstanceFound = -1;

	//// check to see if the vector already has this instance in it's container
	for (int i = 0; i < inventory.size(); i++)
	{
		// Check container for instance match, record the last instance of that itemDef
		if (inventory[i].GetItemDefinition()->GetUniqueId() == aItemInstance.GetItemDefinition()->GetUniqueId())
		{
			LastInstanceFound = i;
		}
	}			// if it does exist, do a IsFull check of that instance, and one to it's stack if false inside of the instance itself

	// if any instances containing the same itemDef that was already found in your inventory, do this ->
	if (LastInstanceFound >= 0)
	{
		// go from the back of the vector to the front, adding to the stack, or pushing a new instance onto the back of the container
		if (inventory[LastInstanceFound].GetItemDefinition()->GetMaxStackSize() > inventory[LastInstanceFound].GetStackCount())
		{
			inventory[LastInstanceFound].AddOneToStack();
			return;
		}
		else
		{
			inventory.push_back(aItemInstance);
			return;
		}
	}
	//IF NO DUPLICATES are found, then adds an instance to the end of the vector
	inventory.push_back(aItemInstance);
}

// removes item from inventory
void Inventory::RemoveItemFromInventory()
{
	inventory.pop_back();
}

// checks to see if inventory can hold item
bool Inventory::CanInventoryHoldItem(ItemDef & aItemDef)
{	
	ItemType itemType = aItemDef.GetItemType();
	ItemType ConditionCheck = ItemType(itemType & inventoryType);

	if (itemType == ConditionCheck)
	{
		return true;
	}
	else
		return false;
}

// Adds an inventory type to the inventoryType vector, based on user input
void Inventory::AddInventoryType(ItemType aItemType)
{
	inventoryType = ItemType(inventoryType | aItemType);
}

// Removes an Inventory type based on user input
void Inventory::RemoveInventoryType(ItemType aItemType)
{
	inventoryType = ItemType(inventoryType & (~aItemType));
}

// Prints what is currently in the inventory
void Inventory::Print()
{
	std::cout << std::endl;
	std::cout << "The Inventory currently occupy " << inventory.size() << " slots.\n\n";
	
	for (int i = 0; i < inventory.size(); i++)
	{		
		std::cout << "Item " << i + 1 << " Name: " << inventory[i].GetItemDefinition()->GetName() << std::endl;
		std::cout << "Item " << i + 1 << " Unique ID: " << inventory[i].GetItemDefinition()->GetUniqueId() << std::endl;
		std::cout << "Item " << i + 1 << " ItemType: " << inventory[i].GetItemDefinition()->GetItemTypeName() << std::endl;
		std::cout << "Item " << i + 1 << " Stack is: " << inventory[i].GetStackCount();
		std::cout << "/" << inventory[i].GetItemDefinition()->GetMaxStackSize() << std::endl << std::endl;
	}
}

// Checks to see if there are still leftover items associated with an Itemtype that has been removed from your Inventory
void Inventory::SanityCheckInventory(ItemType aItemType)
{
	for (int i = 0; i < inventory.size(); i++)
	{
		ItemType foundType = inventory[i].GetItemDefinition()->GetItemType();
		if (foundType == aItemType)
		{
			inventory.erase(inventory.begin() + i);
			i = 0;
		}		
	}

	if (aItemType == inventory[0].GetItemDefinition()->GetItemType())
	{
		inventory.erase(inventory.begin());
	}
}

// Consolidates your inventory if the stack size has been extended on existing ItemDefs
void Inventory::ConsolidateInventory()
{

// check all items in inventory

	for (int i = 0; i < inventory.size(); i++)
	{
		// for each item, check for duplicate itemInstances ItemDef->Unique IDs
		int FoundUniqueID = inventory[i].GetItemDefinition()->GetUniqueId();

		for (int j = 1; j < inventory.size(); j++)
		{
			// if multiple IDs exist of the same unique ID
			if (FoundUniqueID == inventory[j].GetItemDefinition()->GetUniqueId())
			{
				// check to see if the first instance of that item stack size's is full
				if (inventory[i].GetStackCount() < inventory[i].GetItemDefinition()->GetMaxStackSize())
				{
					// if the first stack is not full, fill the first stack until full
					inventory[i].AddOneToStack();
					inventory[j].RemoveOneFromStack();
					if (inventory[j].GetStackCount() == 0)
					{
						RemoveItemFromInventory();
					}
				}					
			}
		}
	}

}

// Takes items out Instances where the stack size is too big for it's current slot, and creates the appropriate number of instances to compensate
// for it's reduced stack size
void Inventory::ExpandInventory() 
{
	int AmountOver = 0;
	// check each item in inventory
	for (int i = 0; i < inventory.size(); i++)
	{
		// get the item instance stack count, and compare it to the max stack size allotted
		int CurrentStackCount = inventory[i].GetStackCount();
		int CurrentMaxStackCount = inventory[i].GetItemDefinition()->GetMaxStackSize();
		// if the item stack count is greater than amount allowed 
		if (CurrentMaxStackCount < CurrentStackCount)
		{
			AmountOver = CurrentStackCount - CurrentMaxStackCount;
			// for each item over the limit
			for (int j = 0; j < AmountOver; j++)
			{
				// add an instance of the item normally
				inventory[i].RemoveOneFromStack();
				AddItemToInventory(inventory[j]);
			}
		}				
	}
}

