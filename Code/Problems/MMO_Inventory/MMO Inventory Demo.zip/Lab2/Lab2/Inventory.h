#pragma once
#include <vector>
#include "ItemInstance.h"
#include "ItemDef.h"

// This class holds an inventory of ItemInstances
// Inventories should respect the max stack size that item definitions have
// Inventories also have a inventoryType, which stores all of the valid types of items that
//		this inventory can hold.

class Inventory
{
public:
	Inventory(ItemType aItemType);
	~Inventory();

	// Add a new item to this inventory
	// If the same item is already in this inventory, it should increment the stack size by one
	void AddItemToInventory(ItemInstance aItemInstance);

	void RemoveItemFromInventory();

	// Check if a given ItemDef can go into the inventory
	bool CanInventoryHoldItem(ItemDef &aItemDef);

	// Add or remove a type of item this inventory can hold
	// When a type is removed, it should remove any items that the inventory can no longer hold
	void AddInventoryType(ItemType aItemType);
	void RemoveInventoryType(ItemType aItemType);

	// Print the items that are currently in the inventory
	void Print();

	// SanityCheckInventory should make sure that all items can exist in this inventory
	// If an item is discovered that shouldn't exist in the inventory, it should display this
	//	and fix the issue. This could be due to incompatible types, or exceeding the max stack size
	void SanityCheckInventory(ItemType aItemType);

	void ConsolidateInventory();

	void ExpandInventory();

private:

	// What types of items can this inventory hold
	ItemType inventoryType;

	// Holds the item instances currently in this inventory
	std::vector<ItemInstance> inventory;


};

