// *** Lab2 - MMO INVENTORY SYSTEM *** 

#include <iostream>
#include <vector>
#include <map>
#include <limits>
#include "ItemDef.h"
#include "Inventory.h"
/*
We're building an mmo, and we've been tasked to create a tool that allows our designers
to add items into the game, and simulate a player's inventory. This is that tool.
*/

ItemDef *CreateNewItemDef();
ItemType SelectType();
void PrintItemDefinitions(std::map<unsigned int, ItemDef*> itemDefinitions);

int main()
{

//	// Variable to designate the user's selection on the main menu
	char userInput = 0;
	char quit = 0;
	
// Data structures to hold the item definitions and the player inventory
	std::map<unsigned int, ItemDef*> itemDefinitions;
	std::map<unsigned int, ItemDef*>::iterator it;
	Inventory playerInventory(ItemType::WEAPON);

	std::cout << "-- Welcome to the MMO Inventory System --" << std::endl;
	std::cout << "-- Initially, your bag is only able to hold weapons --" << std::endl << std::endl;
	// Loop a main menu
	do
	{		

//		- Print the current inventory
//		- Add a new item instance to the player's inventory
//		- Modify what kind of items the inventory can hold
//		- Change the max stack size of an ItemDef
//		- Change the item type of an ItemDef
		
		// Clear the console window
		

		// Print the menu
		
		std::cout << "1. Create a new Item Definition" << std::endl;
		std::cout << "2. Print all of the item definitions" << std::endl;
		std::cout << "3. Add a new item instance to the player's inventory" << std::endl;
		std::cout << "4. Print the current inventory" << std::endl;
		std::cout << "5. Modify what kind of items the inventory can hold" << std::endl;
		std::cout << "6. Remove an ItemType the inventory can hold." << std::endl;
		std::cout << "7. Change the max stack size of an ItemDef" << std::endl;
		std::cout << "8. Change the item type of an ItemDef" << std::endl << std::endl;
		std::cout << "Option #: ";
		
		// Get the user's input
		std::cin >> userInput;

		// Do logic based on the menu selection
		// 1. Create a new item definition
		switch (userInput)
		{

		// Create the new item, store it in the itemDefinitions map
		case '1':
		{			
			ItemDef *newItemDefinition = CreateNewItemDef(); // TODO be sure to delete the pointer data upon destruction
			itemDefinitions[newItemDefinition->GetUniqueId()] = newItemDefinition;
		}
		break;
		
		// Prints the information for each item definition
		case '2':
		{			
			PrintItemDefinitions(itemDefinitions);
		}
		break;
		
		// Adds a new item instance to the player inventory
		case '3':
		{
			int UniqueIDNumber;
			bool doesMatch = false;
			std::cout << "Enter a Item UniqueID: ";
			std::cin >> UniqueIDNumber;
			for (std::map<unsigned int, ItemDef*>::iterator it = itemDefinitions.begin(); it != itemDefinitions.end(); ++it)
			{
				if (UniqueIDNumber == it->second->GetUniqueId())
				{
					if (playerInventory.CanInventoryHoldItem(*(it->second)))
					{
						doesMatch = true;
						ItemInstance itemInstance(it->second);
						playerInventory.AddItemToInventory(itemInstance);
						break;
					}
				}
				else
				{
					doesMatch = false;
				}
			}

			if (!doesMatch)
			{
				std::cout << "The Unique ID you added does not match any known Item Definitions. \n";
			}
		}
		break;
		
		// Print Inventory Information
		case '4':
		{
			playerInventory.Print();
		}
		break;
		
		// Add Item Type to Inventory
		case '5':
		{
			playerInventory.AddInventoryType(SelectType()); 
		}
		break;
		// Removes Item Type as well as any corresponding items
		case '6':
		{
			ItemType RemoveItemType = SelectType();
			playerInventory.RemoveInventoryType(RemoveItemType); // TODO, add user input, double check this
			playerInventory.SanityCheckInventory(RemoveItemType);
		}
		break;

		// Changes the max stack size of an ItemDef
		// Refactors inventory slots according to new stack size
		case '7':
		{
			int UniqueIDNumber;
			std::cout << "Enter a Item UniqueID to change the max stack size for that item: ";
			std::cin >> UniqueIDNumber;

			for (std::map<unsigned int, ItemDef*>::iterator it = itemDefinitions.begin(); it != itemDefinitions.end(); ++it)
			{
				if (UniqueIDNumber == it->second->GetUniqueId())
				{
					int newStacksize;
					std::cout << "What do you want the new max stack size to be?" << std::endl;
					std::cin >> newStacksize;
					it->second->SetMaxStackSize(newStacksize);
					playerInventory.ConsolidateInventory();
					playerInventory.ExpandInventory(); // Not working yet
				}
			}
		}
		break;

		// Change the itemType of a ItemDef
		case '8':
		{
			int UniqueIDNumber;
			std::cout << "Enter a unique ID of item that you want to change: ";
			std::cin >> UniqueIDNumber;
			for (std::map<unsigned int, ItemDef*>::iterator it = itemDefinitions.begin(); it != itemDefinitions.end(); ++it)
			{ 
				if (UniqueIDNumber == it->second->GetUniqueId())
				{
					ItemType newItemtype = SelectType();
					it->second->SetItemType(newItemtype);
				}
				else
				{
					std::cout << "You entered an invalid Item ID number!" << std::endl;
				}
			}			
		}
		break;
		default:
		{
			std::cout << "Invalid Input, please enter 1-7 to select the corresponding option.\n";
		}
		break;
		}
		
		// Prompt the user if they would like to continue
		std::cout << "Would you like to quit? (y/n)" << std::endl;
		std::cin >> quit;
		system("cls");
	} while (quit != 'y');

	// Make sure to delete anything you've allocated (such as the item definitions inside the itemDefinitions map!)
	for (it = itemDefinitions.begin(); it!= itemDefinitions.end(); ++it)
	{
		delete it->second;
	}
	
	return 0;
}

// Creates an new Item Definition based on user input, and returns it to call
ItemDef * CreateNewItemDef()
{	
	std::string name;
	int maxStackSize = 0;
	std::cin.ignore();
		
	std::cout << "\nWhat do you want the name of your ItemDef to be: ";
	std::getline(std::cin, name);

	// What do you want your ItemType to be?
	ItemType NewDefItemType = SelectType();
	std::cout << "What do you want the Maximum Stack Size to be (between 0 - 99): ";
	do {
		while (!(std::cin >> maxStackSize))
		{
			std::cout << "Invalid Input.  Please re-enter. \n";
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		}

	} while (maxStackSize <= 0 && maxStackSize >= 99);

	return new ItemDef(name, NewDefItemType, maxStackSize);
}

// Select what type of the item you want to use.  Returns the enum associated with item type depending on what number is entered
ItemType SelectType()
{
	ItemType itemType;
	char itemID = '6';
	std::cout << "\nWhat item type will this ItemDef belong to ? \n";
	std::cout << "0. Weapon\n";
	std::cout << "1. Armor\n";
	std::cout << "2. Consumable\n";
	std::cout << "3. Crafting Material\n";
	std::cout << "4. Wearable\n";
	std::cout << "5. Bind On Pickup\n\n";
	std::cout << "Item #: ";
	std::cin >> itemID;
	
	switch (itemID)
	{
	case '0':
	{
		itemType = ItemType::WEAPON;
	}
	break;
	case '1':
	{
		itemType = ItemType::ARMOR;
	}
	break;
	case '2':
	{
		itemType = ItemType::CONSUMABLE;
	}
	break;
	case '3':
	{
		itemType = ItemType::CRAFTING_MATERIAL;
	}
	break;
	case '4':
	{
		itemType = ItemType::WEARABLE;
	}
	break;
	case '5':
	{
		itemType = ItemType::BIND_ON_PICKUP;
	}
	// Recursion!! Nice
	default:
	{
		itemType = ItemType::DEFAULT;
		std::cout << std::endl << "This is an unrecognized ItemType, Please type 1-6 for the appropriate ItemType";
		SelectType();
	}
	break;
	}	
	return itemType;
}

// Prints info about the definition list
void PrintItemDefinitions(std::map<unsigned int, ItemDef*> itemDefinitions)
{
	std::cout << std::endl;

	for (std::map<unsigned int, ItemDef*>::iterator it = itemDefinitions.begin(); it != itemDefinitions.end(); ++it)

	{
		std::cout << "Item " << (it->first) << " Name: " << it->second->GetName() << "\n";
		std::cout << "Item " << (it->first) << " Unique ID: " << it->second->GetUniqueId() << "\n";
		std::cout << "Item " << (it->first) << " ItemType: " << it->second->GetItemTypeName() << "\n";
		std::cout << "Item " << (it->first) << " MaxStackSize: " << it->second->GetMaxStackSize() << "\n\n";
	}
}

