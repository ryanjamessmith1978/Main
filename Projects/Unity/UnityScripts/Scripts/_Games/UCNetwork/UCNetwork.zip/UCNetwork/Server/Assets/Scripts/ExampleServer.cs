﻿using System;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using LitJson;

public class ExampleServer : MonoBehaviour
{
    public static ExampleServer instance;

    public ServerNetwork serverNet;

    // Name of the server
    public string serverName = "DaveDevelopmentServer";
    public int portNumber = 603;
    
    // Use this for initialization
    void Awake()
    {
        instance = this;

        // Initialization of the server network
        ServerNetwork.port = portNumber;
        if (serverNet == null)
        {
            serverNet = GetComponent<ServerNetwork>();
        }
        if (serverNet == null)
        {
            serverNet = (ServerNetwork)gameObject.AddComponent(typeof(ServerNetwork));
            Debug.Log("ServerNetwork component added.");
        }

        //serverNet.EnableLogging("rpcLog.txt");
    }

    // Start it up
    void Start()
    {
        
    }
    
    // A client has just requested to connect to the server
    void ConnectionRequest(ServerNetwork.ConnectionRequestInfo data)
    {
        Debug.Log("Connection request from " + data.username);

        // We either need to approve a connection or deny it
        serverNet.ConnectionApproved(data.id);

        // Deny the request
        //serverNet.ConnectionDenied(data.id);
    }

    void OnClientConnected(long aClientId)
    {
        
    }
    
    // The server network wants to send any data needed to initialize a network object on a specific client
    // This happens when clients first connect or change areas
    void InitializeNetworkObject(ServerNetwork.InitializationInfo aInfo)
    {
        
    }

    void OnClientDisconnected(long aClientId)
    {
        
    }
    
    // A new object was just instantiated over the network
    void OnInstantiateNetworkObject(ServerNetwork.IntantiateObjectData aObjectData)
    {
        
    }

    public void OnAddArea(ServerNetwork.AreaChangeInfo info)
    {
        
    }

    public void AddedPlayerToArea(int aNetObjId)
    {
        
    }

    // An object was just removed from the network
    void OnDestroyNetworkObject(int aNetworkId)
    {
        
    }
}
